﻿using UnityEngine;
using System.Collections;

public class Enemy : MonoBehaviour {

	public float speed; // speed of enemy, can be changed in the inspector
	public Transform player; // location of the player, can be set in inspector

	void FixedUpdate()
	{
		float z = Mathf.Atan2 ((player.transform.position.y - transform.position.y), 
		                       (player.transform.position.x - transform.position.x))
			* Mathf.Rad2Deg - 90; // set a float z based on its transform and the players transform, set to degrees from radians

		transform.eulerAngles = new Vector3 (0, 0, z); // rotate enemy based on Z result

		rigidbody2D.AddForce (gameObject.transform.up * speed); // move enemy towards player
	}
    public void Hit()// function to be implemented to hurt and kill player
    {
        //TODO thing to make sure things
        //gameObject.SetActive
    }
}
