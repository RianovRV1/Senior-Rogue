﻿using UnityEngine;
using System.Collections;

public class Player : MonoBehaviour 
{
	public float speed;
    
	Animator anim;
	void Start() //gets animator componant 
	{
		anim = GetComponent<Animator> ();
        
	}

	void Update()
	{
		if (Input.GetKeyDown(KeyCode.Space))// call attack animation on space
		{
            Attack();
		}
        var move = new Vector3(Input.GetAxis("Horizontal"), Input.GetAxis("Vertical"), 0); // W A S D movement set up
        transform.position += move * speed * Time.deltaTime; // actual physics being applied 
        if (Input.GetKey(KeyCode.D)) // setting character to facing right
        {
            var rot = Quaternion.identity;
            rot.eulerAngles = new Vector3(0, 0, -90);
            transform.rotation = rot;
        }
        if (Input.GetKey(KeyCode.A))//setting character to facing left
        {
            var rot = Quaternion.identity;
            rot.eulerAngles = new Vector3(0, 0, 90);
            transform.rotation = rot;
        }
        if (Input.GetKey(KeyCode.W))//setting character to facing up
        {
            var rot = Quaternion.identity;
            rot.eulerAngles = new Vector3(0, 0, 0);
            transform.rotation = rot;
        }
        if (Input.GetKey(KeyCode.S)) //setting character to facing down
        {
            var rot = Quaternion.identity;
            rot.eulerAngles = new Vector3(0, 0, 180);
            transform.rotation = rot;
        }
        rigidbody2D.isKinematic = true;
        rigidbody2D.isKinematic = false; //making sure physics applied to the character get reset so it doesnt cause unintended results, may need to change this in the future
            
	}


    

    void Attack()//attack 
    {
        anim.SetTrigger("Attack");
    }
}
