﻿using UnityEngine;
using System.Collections;

public class RoomManager : MonoBehaviour {

    public GameObject Room;// all the room prefabs for the room manager to place 
    public GameObject LRoom;
    public GameObject TRoom;
    public GameObject FourRoom;
    public GameObject DashRoom;
    public GameObject Player; //player in the scene view, for placement purposes
    public GameObject Enemy; // enemy prefab, for placement purposes
    public GameObject Item; //item  prefab for placement purposes
    public Camera camera;// camera for setting room script's camera
    private float //offset values for room instanciation 
        _offsetx = 78f,
        _offsety = 78f,
        _rotationOffset = 90f;
    
    // Use this for initialization
	void Start () 
    {
        // hard codes room, enemy, item, and player placement
        SpawnEntity(Player, Enemy, Item, MakeRoom(_rotationOffset * 2, 0, _offsety, LRoom));
        SpawnEntity(null, Enemy, Item, MakeRoom(0, 0, 0, Room));
    }
	
	// Update is called once per frame
	void Update () 
    {
     
	}
    public Room MakeRoom(float rotation, float xoffset, float yoffset, GameObject roomType) //function that makes a room taking in the offset values and the room prefab types
    {
        var _room = roomType.GetComponent<Room>(); //looks for room script
        _room.camera = camera; // sets rooms camera
        _room.transform.position = new Vector3(xoffset, yoffset); // sets its position based on offset
        var rot = Quaternion.identity; // value to set a quaternion rotation
        rot.eulerAngles = new Vector3(0, 0, rotation); // use of Euler angles to set rotation, based on rotation offset
        _room.transform.rotation = rot; // setting rooms rotation to the rotation offset
        
       Instantiate(_room, _room.transform.position,  _room.transform.rotation); // creating room clone in the scene view
       return _room; // returns the room object for spawning entities
    }
    public void SpawnEntity(GameObject playerEntity, GameObject enemyEntity, GameObject itemEntity, Room room) // function used to actually spawn the objects into rooms, takes in player, item, and enemy entity, as well as the room to place it in
    {
        if(playerEntity != null) // if not null, get player component then set the player to the center of the room
        {
            var player = playerEntity.GetComponent<Player>();
            Player.transform.position = room.transform.position;
        }
        if(enemyEntity != null) // if not null, get enemy component then set the enemy to specified positon in the room, set its player transform value to the globally decalared player transform value in the RoomManager script
        {
            var enemy = enemyEntity.GetComponent<Enemy>();
            enemy.player = Player.transform;
            Instantiate( enemy, room.transform.position + new Vector3(10, 10), transform.rotation);
        }
        if(itemEntity != null)// if item is not null, get the item component the set its postion to the specfied postion within the room
        {
            var item = itemEntity.GetComponent<Item>();
            Instantiate(itemEntity, room.transform.position + new Vector3(2, -10), transform.rotation);
        }
       
        
    }
}
